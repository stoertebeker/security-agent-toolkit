# OpenCode Firmware Security Analysis Kit

## 1. Firmware ablegen

Lege die zu analysierende Firmware unter `original/` ab, zum Beispiel:

```bash
cp ~/Downloads/tplink.bin original/firmware.bin
sha256sum original/firmware.bin > original/SHA256SUMS
chmod -R a-w original
```

## 2. OpenCode prüfen

```bash
opencode agent list
opencode debug config
```

## 3. OpenCode starten

```bash
./start-opencode.sh
```

`start-opencode.sh` setzt `TMPDIR`, `TMP` und `TEMP` auf `./work/tmp` und aktiviert `OPENCODE_ENABLE_EXA=1` für die Websuche des Research-Subagents.

## 4. Analyse starten

Kopiere den Inhalt von `START_PROMPT.txt` in die OpenCode-Session.

## Projektstruktur

- `original/`: unveränderte Firmware
- `extracted/`: extrahierte Firmware-Dateien
- `work/tmp/`: temporäre Arbeitsdateien statt `/tmp`
- `ghidra/`: Ghidra-Projekte
- `reports/subagents/`: ausführliche Subagent-Berichte
- `findings/`: verdichtete Ergebnisse

Der Primary Agent ist `firmware-security`. Er delegiert an maximal zwei Subagents gleichzeitig:

- `firmware-explorer`
- `binary-reverser`
- `firmware-researcher`
- `security-validator`

Subagents dürfen keine weiteren Subagents starten (`subagent_depth: 1` plus `task: deny`).
