#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
mkdir -p work/tmp extracted ghidra reports/subagents findings original

export TMPDIR="$PWD/work/tmp"
export TMP="$PWD/work/tmp"
export TEMP="$PWD/work/tmp"
export OPENCODE_ENABLE_EXA=1

exec opencode --agent firmware-security
