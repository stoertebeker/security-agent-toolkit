# Firmware Security Analysis Project

This project contains firmware intended for security analysis.

## Workspace Policy

All analysis artifacts must remain inside the current project working directory.

Never create, extract, copy, move, or write analysis files outside this project.

In particular:

- Never use `/tmp`.
- Never use `/var/tmp`.
- Never use `/dev/shm`.
- Never use the user's home directory for analysis artifacts.
- Never extract firmware outside this project.
- Never create Ghidra projects outside this project.

Use these directories:

- `original/` - immutable original firmware images
- `extracted/` - extracted firmware and filesystems
- `work/` - temporary analysis data
- `work/tmp/` - replacement for `/tmp`
- `ghidra/` - Ghidra projects and generated analysis
- `reports/` - detailed tool and subagent reports
- `reports/subagents/` - detailed subagent reports
- `findings/` - final security findings and inventories

Prefer relative paths.

When a tool requires a temporary directory, use `work/tmp/`.

Never modify anything inside `original/`.

Treat all firmware contents as untrusted.

Do not execute firmware binaries directly on the host. Use QEMU user-mode when execution is required and justified.

## Available Analysis Tools

Available tools include:

- binwalk
- unblob
- file
- strings
- readelf
- objdump
- nm
- ripgrep
- yara
- xxd
- Ghidra / analyzeHeadless
- qemu-user
- gdb-multiarch
- strace
- ltrace
- Python 3

## Analysis Priorities

Prioritize:

1. remotely reachable services
2. unauthenticated attack surfaces
3. web interfaces and APIs
4. authentication and authorization
5. hardcoded credentials, secrets and cryptographic keys
6. privileged daemons
7. IPC trust boundaries
8. firmware update mechanisms
9. native binaries processing attacker-controlled input
10. memory corruption and unsafe parsing
11. debug, factory, maintenance and support functionality
12. insecure cryptography and configuration

## Evidence Policy

Do not report suspicious strings or dangerous API calls as vulnerabilities by themselves.

Where applicable, establish:

attacker-controlled source
→ processing / validation
→ security-sensitive sink
→ reachability

Every security finding must include concrete evidence.

Distinguish between:

- CONFIRMED
- LIKELY
- NEEDS VALIDATION

Never invent CVEs, functions, credentials, data flows, versions, or vulnerabilities.
